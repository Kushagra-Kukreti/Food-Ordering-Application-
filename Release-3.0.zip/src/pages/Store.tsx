
import StoreItem from "../components/StoreItem";

import storeItems from "../data/items.json";

const Store = () => {
 
  return (
    <>
      <h1>Store </h1>
      <div className="row">
      {storeItems.map((item,index) => (
        <div key={index} className="col-sm-12 col-md-6 col-lg-4 col-xl-4 mb-3">
            <StoreItem  id={item.id} url={item.imgUrl} price={item.price} title={item.name} />
        </div>
      ))}
      </div>
    </>
  );
};

export default Store;
