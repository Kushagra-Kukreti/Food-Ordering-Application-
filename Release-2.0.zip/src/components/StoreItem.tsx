import { Link } from "react-router-dom";
import formatNumber from "../utils/Format";

type StoreItemProp = {
  url: string;
  price: number;
  title: string;
};

const quantity = 0;

const StoreItem = ({ url, price, title }: StoreItemProp) => {
  return (
    <div className="card" style={{ width: "18rem;" }}>
      <img src={url} style={{ height: "10rem", objectFit: "cover" }} />
      <div className="d-flex flex-column p-1">
        <div className="d-flex flex-row justify-content-between align-items-baseline m-2">
          <h4 className="card-text">{title}</h4>
          <h5 className="card-text text-muted">{formatNumber(price)}</h5>
        </div>
        {quantity ===0?<Link to={""} className="btn btn-primary w-100">
          Add to Cart
        </Link>:
         <>
         <div className="d-flex align-items-center justify-content-center m-2" style={{gap:"0.5rem"}}>
            <div className="btn  btn-sm btn-primary">+</div>
            <div className="d-flex align-items-baseline">
            <span><h3>{quantity}</h3></span> in Cart
            </div>
            <div className="btn  btn-sm btn-primary">-</div>
         </div>
         <div className="d-flex align-items-center justify-content-center">
            <div className="btn btn-sm btn-danger">Remove</div>
         </div>
         </>
        }
        
      </div>
    </div>
  );
};

export default StoreItem;
