import StoreItem from "../components/StoreItem";
import storeItems from "../data/items.json";

const Store = () => {
  return (
    <>
      <h1>Store </h1>
      <div className="row">
      {storeItems.map((item) => (
        <div className="col-sm-12 col-md-6 col-lg-3 col-xl-4 mb-3">
            <StoreItem url={item.imgUrl} price={item.price} title={item.name} />
        </div>
      ))}
      </div>
    </>
  );
};

export default Store;
