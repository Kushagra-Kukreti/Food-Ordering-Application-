
import storeItems from '../data/items.json'

 
const Store = () => {
  return (
    <>
    <h1>Store </h1>
    {
      storeItems.map(item=>(
        <div className='row sm-1 md-2 lg-3' style={{gap:"0.5rem"}}>
          <div className='col'>
           {JSON.stringify(item)}
          </div>
        </div>
      ))
    }
    </>
  )
}

export default Store
