import React from "react";
import { NavLink } from "react-router-dom";

const Header = () => {
  return (
    <>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid container">
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <NavLink className="nav-link" to={"/"}>
                  Home
                </NavLink>
              </li>

              <li className="nav-item">
                <NavLink className="nav-link" to={"/about"}>
                  About
                </NavLink>
              </li>

              <li className="nav-item">
                <NavLink className="nav-link" to={"/store"}>
                  {" "}
                  Store
                </NavLink>
              </li>
            </ul>
          </div>

          <button  style={{height:"3rem", width:"3rem" ,position:"relative"}}className="btn btn-outline-primary pb-2 pt-1 rounded-circle">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              fill="currentColor"
              className="bi bi-bag-fill "
              viewBox="0 0 16 16"
            >
              <path d="M8 1a2.5 2.5 0 0 1 2.5 2.5V4h-5v-.5A2.5 2.5 0 0 1 8 1m3.5 3v-.5a3.5 3.5 0 1 0-7 0V4H1v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V4z" />
            </svg>
            <div 
            className="bg-danger rounded-circle"
            style={
                {   
                    display:"flex",
                    justifyContent:"center",
                    alignItems:"center",
                    color:"white",
                    right:"0",
                    bottom:"0",
                    position:"absolute",
                    height:"1.5rem",
                    width:"1.5rem",
                    transform:"translate(19%,34%)",
                }
            }
            >4</div>
          </button>
        </div>
      </nav>
    </>
  );
};

export default Header;
