
import { useShoppingCart } from "../context/ShoppingCartContext";


const ShoppingCartItem = () => {

    const {isOpen,closeCart}= useShoppingCart()

    
  return (
    <div
      className={`${"offcanvas offcanvas-end"} ${isOpen=== true?"show":""}`}
      id="offcanvas"
      aria-labelledby="offcanvasLabel"
       tabIndex={-1}
    >
      <div className="offcanvas-header">
        <h5 className="offcanvas-title" id="offcanvasLabel">
          Offcanvas
        </h5>
        <button
          type="button"
          className="btn-close"
          data-bs-dismiss="offcanvas"
          aria-label="Close" 
          onClick={()=>closeCart()}
        ></button>
      </div>
      <div className="offcanvas-body">
        Content for the offcanvas goes here. You can place just about any
        Bootstrap component or custom elements here.
      </div>
    </div>
  );
};

export default ShoppingCartItem;
