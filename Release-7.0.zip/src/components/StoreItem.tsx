
import formatNumber from "../utils/Format";
import { useShoppingCart } from "../context/ShoppingCartContext";

type StoreItemProp = {
  id:number
  url: string;
  price: number;
  title: string;
};




const StoreItem = ({ id,url, price, title }: StoreItemProp) => {
  const {getItemQuantity,increaseCartQuantity,decreaseCartQuantity,removeFromCart} =useShoppingCart();
  const quantity = getItemQuantity(id);

  
  return (
    <div className="card" style={{ width: "22rem"}}>
      <img src={url} style={{ height: "10rem", objectFit: "cover" }} />
      <div className="d-flex flex-column p-1">
        <div className="d-flex flex-row justify-content-between align-items-baseline m-2">
          <h4 className="card-text">{title}</h4>
          <h5 className="card-text text-muted">{formatNumber(price)}</h5>
        </div>
        {quantity ===0?<div  onClick={()=>{increaseCartQuantity(id) }} className="btn btn-primary w-100">
          + Add to Cart
        </div>:
         <>
         <div className="d-flex align-items-center justify-content-center m-2" style={{gap:"0.5rem"}}>
            <div className="btn  btn-sm btn-primary"  onClick={()=>increaseCartQuantity(id)}>+</div>
            <div className="d-flex align-items-baseline">
            <span><h3>{quantity}</h3></span> in Cart
            </div>
            <div className="btn  btn-sm btn-primary"  onClick={()=>decreaseCartQuantity(id)}>-</div>
         </div>
         <div className="d-flex align-items-center justify-content-center">
            <div className="btn btn-sm btn-danger"  onClick={()=>removeFromCart(id)}>Remove</div>
         </div>
         </>
        }
        
      </div>
    </div>
  );
};

export default StoreItem;
