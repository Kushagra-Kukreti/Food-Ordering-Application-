
import { useState } from "react";
import StoreItem from "../components/StoreItem";

import storeItems from "../data/items.json";

const Store = () => {

   const [search , setSearch]  = useState("")
  return (
    <>
      <div style={{display:"flex" ,flexDirection:"row", gap:"0.5rem", alignItems:"baseline",justifyContent:"space-between"}}>
        <h2>Store </h2> 
      <input  type="text" 
      style={{
        width:"60%",
        borderRadius:"0.5rem",
        borderStyle:"none",
        border:"0.15rem black solid",
        outline:"none",
        padding:"0.2rem"
        
      }}
      onChange={(e)=>setSearch(e.target.value)}
      placeholder="search here"
      /></div>

      <div className="row">
      {storeItems.filter(i=>{
        return search.toLowerCase() == " "?i:i.name.toLowerCase().startsWith(search.toLowerCase())
      }).map((item,index) => (
        <div key={index} className="col-sm-12 col-md-6 col-lg-4 col-xl-4 mb-3">
            <StoreItem  id={item.id} url={item.imgUrl} price={item.price} title={item.name} />
        </div>
      ))}
      </div>
    </>
  );
};

export default Store;
